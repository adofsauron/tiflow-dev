---
description: Administration
title: Administration
weight: 40
---

# Administration

This section includes information for Grafana administrators, team administrators, and users performing administrative tasks:

{{< section >}}

For information about authorization and authentication for your Grafana Cloud Stack and Grafana Cloud Portal, refer to [Grafana Cloud Access Policies](/docs/grafana-cloud/authentication-and-permissions/access-policies/).
