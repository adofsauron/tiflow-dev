This devenv docker-compose.yaml will allow you to;
- search traces
- view traces
- upload/download trace JSON files
- view service graphs
- view the APM table
- search traces via Loki
