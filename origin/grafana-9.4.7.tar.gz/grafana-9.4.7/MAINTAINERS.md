@torkelo is the main/default maintainer, some parts of the codebase have other maintainers:

- Backend:
  - @bergquist
- Plugins:
  - @ryantxu
- UX/UI:
  - @davkal
- Docs:
  - @chri2547
  - @brendamuir
  - @gguillotte-grafana
