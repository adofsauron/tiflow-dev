@torkelo is the main/default maintainer, some parts of the codebase have other maintainers:

- Backend:
  - @bergquist
- Plugins:
  - @ryantxu
- UX/UI:
  - @davkal
