---
name: Enhancement request
about: Suggest an enhancement or new feature for the Grafana project
labels: 'type: feature request'
---

<!-- Please only use this template for submitting feature requests -->

**What would you like to be added**:

**Why is this needed**:
