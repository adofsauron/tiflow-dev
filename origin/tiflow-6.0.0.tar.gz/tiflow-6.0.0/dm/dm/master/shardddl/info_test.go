// Copyright 2020 PingCAP, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// See the License for the specific language governing permissions and
// limitations under the License.

package shardddl

import (
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/pingcap/tiflow/dm/pkg/shardddl/pessimism"
)

func TestInfoSlice(t *testing.T) {
	var (
		task          = "task"
		source1       = "mysql-replica-1"
		source2       = "mysql-replica-2"
		source3       = "mysql-replica-3"
		schema, table = "foo", "bar"
		DDLs          = []string{"ALTER TABLE bar ADD COLUMN c1 INT"}
		ifm           = map[string]pessimism.Info{
			source3: pessimism.NewInfo(task, source3, schema, table, DDLs),
			source2: pessimism.NewInfo(task, source2, schema, table, DDLs),
			source1: pessimism.NewInfo(task, source1, schema, table, DDLs),
		}
	)

	ifs := pessimismInfoMapToSlice(ifm)
	require.Len(t, ifs, 3)
	require.Equal(t, ifm[source1], ifs[0])
	require.Equal(t, ifm[source2], ifs[1])
	require.Equal(t, ifm[source3], ifs[2])
}
