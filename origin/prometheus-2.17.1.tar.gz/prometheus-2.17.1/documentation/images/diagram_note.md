The architecture image was drawn on https://www.draw.io/. The native draw.io
source file is called `architecture.xml`, while `architecture.svg` is its SVG
export.

To change the architecture diagram, go to https://www.draw.io/ and import the
XML source file. After making changes to the diagram, export the result as SVG.
Update both the source file and the SVG export in this directory.
